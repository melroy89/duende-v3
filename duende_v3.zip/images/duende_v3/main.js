(function($) {
    $(document).ready(function() {
        // Menu
        $('#cssmenu').prepend('<div id="indicatorContainer"><div id="pIndicator"><div id="cIndicator"></div></div></div>');
        var activeElement = $('#cssmenu>ul>li:first');

        $('#cssmenu>ul>li').each(function() {
            if ($(this).hasClass('active')) {
                activeElement = $(this);
            }
        });

        var posLeft = activeElement.position().left;
        var elementWidth = activeElement.width();
        posLeft = posLeft + elementWidth / 2 - 6;
        if (activeElement.hasClass('has-sub')) {
            posLeft -= 6;
        }

        $('#cssmenu #pIndicator').css('left', posLeft);
        var element, leftPos, indicator = $('#cssmenu pIndicator');

        $("#cssmenu>ul>li").hover(function() {
            element = $(this);
            var w = element.width();
            if ($(this).hasClass('has-sub')) {
                leftPos = element.position().left + w / 2 - 12;
            } else {
                leftPos = element.position().left + w / 2 - 6;
            }

            $('#cssmenu #pIndicator').css('left', leftPos);
        }, function() {
            $('#cssmenu #pIndicator').css('left', posLeft);
        });

        $('#cssmenu>ul').prepend('<li id="menu-button"><a><i class="fa fa-bars" aria-hidden="true"></i>  Menu</a></li>');
        $("#menu-button").click(function() {
            if ($(this).parent().hasClass('open')) {
                $(this).parent().removeClass('open');
            } else {
                $(this).parent().addClass('open');
            }
        });

        // Add tipsy
        $("a").tipsy({
            gravity: $.fn.tipsy.autoNS,
            fade: true
        });
        $("title").tipsy({
            gravity: $.fn.tipsy.autoNS,
            fade: true
        });
        $("img").tipsy({
            gravity: $.fn.tipsy.autoNS,
            fade: true
        });
        $("i").tipsy({
            gravity: $.fn.tipsy.autoNS,
            fade: true
        });
        $("span").tipsy({
            gravity: $.fn.tipsy.autoNS,
            fade: true
        });
        $("div").tipsy({
            gravity: $.fn.tipsy.autoNS,
            fade: true
        });

        // On welcomeblock member, create a default avatar for those without one.
        if ($('.header_avatar img', this).attr('src') == '') {
            $('.header_avatar img').attr('src', "images/duende_v3/default_avatar.png");
        }

        // For member profile page
        $('ul.tabs li').click(function() {
            var tab_id = $(this).attr('data-tab');

            $('ul.tabs li').removeClass('current');
            $('.tab-content2').removeClass('current');

            $(this).addClass('current');
            $("#" + tab_id).addClass('current');
        })

        // Subscribe/unsubscribe icon
        if (document.querySelector('#subscribe') && 
            ($('#subscribe').attr('original-title').includes('unsubscribe') || 
             $('#subscribe').attr('original-title').includes('opzeggen') ||
             $('#subscribe').attr('original-title').includes('abmelden') ||
             $('#subscribe').attr('original-title').includes('cancelar'))) {
            $('#subscribe > i').addClass('fa-star').removeClass('fa-star-o');
        }

        // Scrolling effect 
        var offset = 100;
        var duration = 250;
        $(window).scroll(function() {
            if ($(this).scrollTop() > offset) {
                $(".topforum").fadeIn(duration);
            } else {
                $(".topforum").fadeOut(duration);
            }
        });
        $('.topforum').click(function(event) {
            event.preventDefault();
            $('html, body').animate({
                scrollTop: 0
            }, 600);
            return false;
        })
    });
})(jQuery);
